%%
%����gbn�ź�
clc;
%%
%������ʼʱ��
time_gbn=0;
%����ʱ����
time_span=50;

gbn1=gbngen(5001,30) * 0.03;     %PA
gbn2=gbngen(5001,30) * 0.03;     %AA
gbn3=gbngen(5001,30) * 0.03;     %CCOFA
gbn4=gbngen(5001,30) * 0.03;     %SOFA
gbn5=gbngen(5001,30) * 0.00;     %WFR
gbn6=gbngen(5001,30) * 0.2;      %COAL
gbn7=gbngen(5001,30) * 1* 2.5;   %CR


%����д��
fid=fopen('E:\optimization\OP_IN_1000.txt','wt');
fprintf(fid,'%s\n','8');
fprintf(fid,'%s\n',' SIMULATION TIME');
fprintf(fid,'%s\n',' T1_PA ANALOG_VALUE');
fprintf(fid,'%s\n',' T2_AA ANALOG_VALUE'); 
fprintf(fid,'%s\n',' T3_CCOFA ANALOG_VALUE');
fprintf(fid,'%s\n',' T4_SOFA ANALOG_VALUE');
fprintf(fid,'%s\n',' T5_WFR ANALOG_VALUE'); 
fprintf(fid,'%s\n',' T6_COAL ANALOG_VALUE');
fprintf(fid,'%s\n',' T7_CR ANALOG_VALUE');

i=1;
% for i=1:1:length(gbn1)
%         fprintf(fid,'%s%.4f%s%d%s%d%s%d%s%d%s%d\n','    ',time_gbn,'        ',...
%             gbn1(i),'        ',gbn2(i),'        ',gbn3(i),'        ',gbn4(i),'        ',gbn5(i));
%     time_gbn=time_gbn+time_span;  
% end
for i=1:1:length(gbn1)
        fprintf(fid,'%s%.4f%s%d%s%d%s%d%s%d%s%d%s%d%s%d\n','    ',time_gbn,'        ',...
            gbn1(i),'        ',gbn2(i),'        ',gbn3(i),'        ',gbn4(i),'        ',gbn5(i),'        ',gbn6(i),'        ',gbn7(i));
    time_gbn=time_gbn+time_span;  
end
fclose(fid);
h=warndlg('�����ź����޸�');
